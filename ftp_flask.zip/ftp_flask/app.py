from flask import Flask, render_template, request, send_from_directory, abort
import os

app = Flask(__name__)


def getfile():
    print(os.getcwd())
    path1 = os.getcwd() + '/upload_files'
    path2 = os.getcwd()
    # 跳转目录 跳转到下载文件的目录，获得下载文件目录里面的list之后，然后再跳转出来.
   #这个跳转的步骤是为了获取到upload_files目录下的文件的名字，然后把它放进f_list中
    os.chdir(path1)
    f_list = os.listdir()
    os.chdir(path2)
    print(os.getcwd())
    return f_list


def is_Have_file(filename):
    print(os.getcwd())
    path1 = os.getcwd() + '/upload_files'
    path2 = os.getcwd()
    os.chdir(path1)
    flag = os.path.isfile(filename)
    os.chdir(path2)
    print(os.getcwd())
    return flag


@app.route('/')
def home():
    return render_template('home.html')


@app.route('/upload')
def upload_file():
    return render_template('upload.html')


@app.route('/uploader', methods=['GET', 'POST'])
def upload_success():
    if request.method == 'POST':
        f = request.files['file']
        f.save('upload_files/' + f.filename)
        return render_template('upload_success.html', filename=f.filename)


# 显示下载文件的界面
@app.route('/down', methods=['GET'])
def download_page():
    f_list = getfile()
    return render_template('download_page.html', fl=f_list)


# 下载要下载的文件，要下载的文件是通过get方法来传递的
@app.route('/download_file', methods=['GET'])
def download_file():
    if request.method == 'GET':
        download_filename = request.args.get('filename')
        f_list = getfile()
        print()
        if is_Have_file(download_filename):
            return send_from_directory('upload_files', download_filename, as_attachment=True)
        else:
            abort(404)


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
